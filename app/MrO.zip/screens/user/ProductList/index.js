import Home from './HomeView'
export default Home

export default {
  beauty: [
    { id: 'popular', title: 'Popular' },
    { id: 'beauty', title: 'Beauty' },
    { id: 'fashion', title: 'Fashion' },
    { id: 'clothes', title: 'Clothes'}
  ],
  fashion: [
    { id: 'shoes', title: 'Shoes', },
    { id: 'beauty', title: 'Beauty', },
    { id: 'fashion', title: 'Fashion', },
    { id: 'places', title: 'Places', }
  ],
}

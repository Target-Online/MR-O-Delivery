const Orientation = {
  LANDSCAPE_RIGHT: 'LANDSCAPE-RIGHT',
  LANDSCAPE_LEFT: 'LANDSCAPE-LEFT',
  LANDSCAPE: 'LANDSCAPE'

}

export default {
  Orientation
}
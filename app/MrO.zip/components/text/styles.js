import { StyleSheet } from 'react-native'

import { Colors } from '../../constants'

export default StyleSheet.create({
  text: {
    backgroundColor: Colors.transparent
  }
})
